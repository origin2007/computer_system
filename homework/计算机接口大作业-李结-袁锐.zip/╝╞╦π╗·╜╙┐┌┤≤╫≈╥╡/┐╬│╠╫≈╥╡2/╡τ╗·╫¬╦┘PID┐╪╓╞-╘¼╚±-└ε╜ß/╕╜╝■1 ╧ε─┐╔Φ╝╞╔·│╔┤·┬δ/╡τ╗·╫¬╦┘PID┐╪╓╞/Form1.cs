﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
using System.IO;
using System.Windows.Forms.DataVisualization.Charting;

namespace 电机转速PID控制
{
    public partial class Form1 : Form
    {
        SerialPort sp = null;
        bool isOpen = false;
        bool isSetProperty = false;
        bool isHex = false;
        double x1,x2,y;
        double Integral_bias = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //界面基本设置
            this.MaximumSize = this.Size;
            this.MinimumSize = this.Size;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.HelpButton = true;
            groupBox3.BackColor = Color.Transparent;
            groupBox1.BackColor = Color.Transparent;
            groupBox2.BackColor = Color.Transparent;
            chart1.BackColor = Color.Transparent;

            //图表基本设置
            chart1.Series[0].ChartType = SeriesChartType.Line;
            chart1.Series[1].ChartType = SeriesChartType.Line;
            chart1.ChartAreas[0].AxisX.Title = "时刻t  单位10ms";
            chart1.ChartAreas[0].AxisY.Title = "角速度w   单位rad/s";
            chart1.Series[0].BorderWidth = 2;
            chart1.Series[1].BorderWidth = 2;
            chart1.Series[0].Color = Color.BlueViolet;
            chart1.Series[1].Color = Color.Red;

            //支持最大串口10，也课自行输入串口号
            for (int i = 0; i < 10; i++)
            {
                cbxCOMPort.Items.Add("COM" + (i + 1).ToString());
            }
            cbxCOMPort.SelectedIndex = 0;
            //列出常用波特率
            cbxBaudRate.Items.Add("1200");
            cbxBaudRate.Items.Add("2400");
            cbxBaudRate.Items.Add("4800");
            cbxBaudRate.Items.Add("9600");
            cbxBaudRate.Items.Add("19200");
            cbxBaudRate.Items.Add("38400");
            cbxBaudRate.Items.Add("56000");
            cbxBaudRate.Items.Add("57600");
            cbxBaudRate.Items.Add("115200");
            cbxBaudRate.SelectedIndex = 5;
            //列出停止位
            cbxStopBits.Items.Add("0");
            cbxStopBits.Items.Add("1");
            cbxStopBits.Items.Add("1.5");
            cbxStopBits.Items.Add("2");
            cbxStopBits.SelectedIndex = 1;
            //列出数据位
            cbxDataBits.Items.Add("8");
            cbxDataBits.Items.Add("7");
            cbxDataBits.Items.Add("6");
            cbxDataBits.Items.Add("5");
            cbxDataBits.SelectedIndex = 0;
            //列出校验位
            cbxParity.Items.Add("无");
            cbxParity.Items.Add("奇校验");
            cbxParity.Items.Add("偶校验");
            cbxParity.SelectedIndex = 2;
            rbnChar.Checked = true;
        }

        private void btnCheckCOM_Click(object sender, EventArgs e)
        {
            bool comExistence = false;//有可用串口标志位
            cbxCOMPort.Items.Clear();//清除当前串口号中的所有串口名称
            for (int i = 0; i < 10; i++)
            {
                try
                {
                    SerialPort sp = new SerialPort("COM" + (i + 1).ToString());
                    sp.Open();
                    sp.Close();
                    cbxCOMPort.Items.Add("COM" + (i + 1).ToString());
                    comExistence = true;
                }
                catch (Exception)
                {
                    continue;
                }
            }
            if (comExistence)
            {
                cbxCOMPort.SelectedIndex = 0;//使用ListBox显示第一个添加的索引
            }
            else
            {
                MessageBox.Show("没有找到可用串口！", "错误提示");
            }
        }

        //检测串口是否设置
        private bool CheckPortSeting()
        {
            if (cbxCOMPort.Text.Trim() == "") return false;
            if (cbxBaudRate.Text.Trim() == "") return false;
            if (cbxDataBits.Text.Trim() == "") return false;
            if (cbxParity.Text.Trim() == "") return false;
            if (cbxStopBits.Text.Trim() == "") return false;
            return true;
        }

        //检查发送的数据中是否含有空格，如果有，则去掉
        private bool CheckSendData()
        {
            if (tbxSetSpeed.Text.Trim() == "") return false;
            return true;
        }

        //设置串口属性
        private void SetPortProperty()
        {
            sp = new SerialPort();
            sp.PortName = cbxCOMPort.Text.Trim();//设置串口名
            sp.BaudRate = Convert.ToInt32(cbxBaudRate.Text.Trim());
            float f = Convert.ToSingle(cbxStopBits.Text.Trim());
            if (f == 0)
            {
                sp.StopBits = StopBits.None;
            }
            else if (f == 1.5)
            {
                sp.StopBits = StopBits.OnePointFive;
            }
            else if (f == 1)
            {
                sp.StopBits = StopBits.One;
            }
            else if (f == 2)
            {
                sp.StopBits = StopBits.Two;
            }
            sp.DataBits = Convert.ToInt16(cbxDataBits.Text.Trim());//设置数据位
            string s = cbxParity.Text.Trim();//设置校验位
            if (s.CompareTo("无") == 0)
            {
                sp.Parity = Parity.None;
            }
            else if (s.CompareTo("奇校验") == 0)
            {
                sp.Parity = Parity.Odd;
            }
            else if (s.CompareTo("偶检验") == 0)
            {
                sp.Parity = Parity.Even;
            }
            else
            {
                sp.Parity = Parity.None;
            }
            sp.ReadTimeout = -1;//设置超时时间
            sp.RtsEnable = true;
            //定义DataReceived事件，当串口收到数据后触发该事件
            sp.DataReceived += new SerialDataReceivedEventHandler(sp_DataReceived);
            if (rbnHEX.Checked)
            {
                isHex = true;
            }
            else
            {
                isHex = false;
            }
        }
        
        //打开串口
        private void btnOpenPort_Click(object sender, EventArgs e)
        {
            if (isOpen == false)
            {
                if (!CheckPortSeting())
                {
                    MessageBox.Show("串口未设置！", "错误提示");
                    return;
                }
                if (!isSetProperty)//串口未设置则设置串口
                {
                    SetPortProperty();
                    isSetProperty = true;
                }
                try//尝试打开串口
                {
                    sp.Open();
                    isOpen = true;
                    btnOpenPort.Text = "关闭串口";
                    //串口打开后相关串口设置将不能再修改
                    cbxCOMPort.Enabled = false;
                    cbxBaudRate.Enabled = false;
                    cbxDataBits.Enabled = false;
                    cbxStopBits.Enabled = false;
                    cbxParity.Enabled = false;
                    rbnChar.Enabled = false;
                    rbnHEX.Enabled = false;
                }
                catch (Exception)
                {
                    //打开串口失败后，相应标志位取消
                    isSetProperty = false;
                    isOpen = false;
                    MessageBox.Show("串口打开失败或被占用！", "错误提示");
                }
            }
            else
            {
                try //打开串口
                {
                    sp.Close();
                    isOpen = false;
                    isSetProperty = false;
                    btnOpenPort.Text = "打开串口";
                    //串口关闭后相关串口设置将恢复可再修改
                    cbxCOMPort.Enabled = true;
                    cbxBaudRate.Enabled = true;
                    cbxDataBits.Enabled = true;
                    cbxStopBits.Enabled = true;
                    cbxParity.Enabled = true;
                    rbnChar.Enabled = true;
                    rbnHEX.Enabled = true;
                }
                catch (Exception)
                {
                    MessageBox.Show("关闭串口时发生错误！", "错误提示");
                }
            }
        }

        //发送串口数据
        private void btnSendData_Click(object sender, EventArgs e)
        {
            if (isOpen)//写串口数据
            {
                try
                {
                    sp.WriteLine(tbxSetSpeed.Text);
                }
                catch (Exception)
                {
                    MessageBox.Show("发送数据时发生错误！", "错误提示");
                    return;
                }
            }
            else
            {
                MessageBox.Show("串口未打开！", "错误提示");
                return;
            }
            if (!CheckSendData())//检测要发送的数据
            {
                MessageBox.Show("请输入要发送的数据！", "错误提示");
                return;
            }
        }

        //接收串口数据
        private void sp_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            System.Threading.Thread.Sleep(100);//延时100ms等待数据接收完毕
            //this.invoke跨越线程访问UI的方法
            this.Invoke((EventHandler)(delegate
            {
                if (isHex == false)
                {
                    tbxRtVoltage.Text += sp.ReadLine();
                }
                else
                {
                    Byte[] ReceivedData = new Byte[sp.BytesToRead];
                    sp.Read(ReceivedData, 0, ReceivedData.Length);
                    string RecvDataText = null;
                    for (int i = 0; i < ReceivedData.Length - 1; i++)
                    {
                        tbxRtVoltage.Text += RecvDataText;
                    }
                }
                sp.DiscardInBuffer();//丢弃接收缓冲区数据

            }));
        }

        //清空参数设定与显示内所有内容
        private void btnClearData_Click(object sender, EventArgs e)
        {
            tbxSetSpeed.Text = "";
            tbxRtSpeed.Text = "";
            tbxRtVoltage.Text = "";
        }

        //离散传递函数迭代计算部分
        public double speed(int Ua)
        {
            double temp1, temp2;
            temp1 = 0.7451 * x1 - 0.0146 * x2 + 0.0087 * Ua;
            temp2 = 0.0087 * x1 + 0.9999 * x2;
            y = 12.6366 * x2;
            x1 = Math.Round(temp1, 3);
            x2 = Math.Round(temp2, 3);
            this.listBox1.Items.Add(y);
            return y;  //返回角速度y
        }

        //将输出y写入到txt文件保存
        private void btSavetotxt_Click(object sender, EventArgs e)
        {
            StreamWriter writer = new StreamWriter(System.Windows.Forms.Application.StartupPath + "/123.txt", true);//写入当前应用路径下的txt文档
            for (int i = 0; i < listBox1.Items.Count; i++)//循环遍历listbox的所有item
            writer.Write(listBox1.Items[i].ToString() + "\r\n");//将每一个item写进文件
            writer.Close();//关闭
        }

        //显示与关闭曲线
        private void button1_Click(object sender, EventArgs e)
        {
            timer2.Interval = 1;
            if (button1.Text == "显示曲线")
            {
                timer2.Enabled = true;
                tbxSetSpeed.Enabled = false;
                button1.Text = "暂停显示";
            }
            else
            {
                timer2.Enabled = false;
                tbxSetSpeed.Enabled = true;
                button1.Text = "显示曲线";
            }
        }

        //timer2设置为true时，设置曲线显示部分内容
        private void timer2_Tick(object sender, EventArgs e)
        {
            y = speed(Convert.ToInt32(tbxRtVoltage.Text));
            tbxRtSpeed.Text = Convert.ToString(y);
            listBox1.Items.Add(y);
            chart1.Series[0].Points.AddY(y);
            chart1.Series[1].Points.AddY(tbxSetSpeed.Text);
        }

        //timer1设置为true，定时1000ms，右下角显示系统日期时间
        private void timer1_Tick(object sender, EventArgs e)
        {
            tbxDataandTime.Text = System.DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
        }

        //窗体右上角帮助按钮显示内容
        private void Form1_HelpButtonClicked(object sender, CancelEventArgs e)
        {
            MessageBox.Show("整个电机转速PID控制分为上位机和下位机，下位机进行PID参数的计算，上位机建立电动机的虚拟模型，"+
                "上位机和下位机通过USB口进行实时数据交换。上位机分为四个部分，参数设定与显示+串口设置+曲线显示+实时数据显示及保存。"+
                "使用时先通过设备管理器查看数据串口，根据通信约定设置通信参数，检查无误后，开始进行通信，进行PID控制。曲线显示部分"+
                "可以显示实时电机转速以及数值，并可将数据保存到TXT文档中，进一步进行分析。                                   软件版本1.0.3                          团队成员：高宁、李翔、胡斌", "使用帮助");
        }

        //电机转速PID控制
        public double PID(double speed)
        {
            double Bias, Pwm;
            Bias = 1500-speed; //计算偏差
            Integral_bias = Bias + Integral_bias; //求出偏差的积分
            Pwm =Convert.ToDouble(P.Text)* Bias + Convert.ToDouble(I.Text) * Integral_bias; //位置式PID控制器
            return Pwm; //增量输出
        }
    }
}
