function [sys,x0,str,ts] = sys(t,x,u,flag)
%SFUNDSC1 Example memory MATLAB file S-function with inherited sample time
%   This MATLAB file S-function is an example of how to implement an
%   inherited sample time S-function which has state. The actual sample
%   time will be determined by what is driving this S-function. It may
%   be continuous or discrete. This S-function uses one discrete state 
%   element as storage such that the previous input is provided at the 
%   output.
%   
%   See sfuntmpl.m for a general S-function template.
%
%   See also SFUNTMPL.
    
%   Copyright 1990-2009 The MathWorks, Inc.

switch flag,

  %%%%%%%%%%%%%%%%%%
  % Initialization %
  %%%%%%%%%%%%%%%%%%
  case 0,
   [sys,x0,str,ts]=mdlInitializeSizes;
    
  %%%%%%%%%%
  % Output %
  %%%%%%%%%%
  case 3,                                               
    sys = mdlOutputs(t,x,u);    

  %%%%%%%%%%%%%
  % Terminate %
  %%%%%%%%%%%%%
  case {1,2,4,9}                                               
   sys=[];
    otherwise
    error('Simulink:blocks:unhandledFlag', num2str(flag));
end
end

%end sfundsc1

%
%=============================================================================
% mdlInitializeSizes
% Return the sizes, initial conditions, and sample times for the S-function.
%=============================================================================
%
function [sys,x0,str,ts]=mdlInitializeSizes

sizes = simsizes;

sizes.NumContStates  = 0;
sizes.NumDiscStates  = 0;
sizes.NumOutputs     = 1;
sizes.NumInputs      = 1;
sizes.DirFeedthrough = 1;
sizes.NumSampleTimes = 1;

sys = simsizes(sizes);

x0  = [];
str = [];
ts  = [0.2 0]; % Inherited sample time

% speicfy that the simState for this s-function is same as the default

end
% end mdlInitializeSizes

%
%=======================================================================
% mdlUpdate
% Handle discrete state updates, sample time hits, and major time step
% requirements.
%=======================================================================
%

%end mdlUpdate

%
%=======================================================================
% mdlOutputs
% Return the output vector for the S-function
%=======================================================================
%
function sys = mdlOutputs(t,x,u)
    global sr3;
    global err;
    global speed;
    b = num2str(u,'%4.1f');
    delete(instrfindall)      % �رմ��ڣ��˾�ʮ����Ҫ����ƪ����ϸ����
    sr3 = serial('COM3');       % ʹ��Ĭ�����ô�������sr3
    sr3.ReadAsyncMode = 'continuous';
    fopen(sr3);%�򿪴���
    set(sr3,'BytesAvailableFcnMode','Terminator'); %�����жϴ�����ʽ
    set(sr3,'Terminator','A');
    sr3.BytesAvailableFcn =@ReceiveCallback;       % �����ж���Ӧ��������
    fprintf(sr3,b);         % ������д������
    pause(1);
%     str = fread(sr3,5)           %��ȡ�������ݣ��޷ֺţ�����Matlab������ʵʱ�鿴��
    h = err + speed/3000;
    if(h>1)
         h=1;
     end
     if(h<0)
         h=0;
     end
     sys = h;
%     fclose(sr3);                %�رմ���
%     delete(sr3);
%     clear sr3;
end
%end mdlOutputs

function ReceiveCallback( obj,event)     %�����ж���Ӧ����   ( obj,event)
   global sr3;
   global err;
   a = fread(sr3,8);      % �������ݲ���ʾ���޷ֺţ�
   err = (a(7)*65535*256+a(6)*65536+a(5)*256+a(4))/100000
   if(a(3)==1) 
       err=-err;
   end
   I = 'I received';    % �����Ƿ��ж���Ӧ�����������������޷ֺţ�
end

